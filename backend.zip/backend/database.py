import sqlite3
import os

DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "claims.db")
SCHEMA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "claim_schema.sql")

def get_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def create_tables():
    conn = get_connection()
    cursor = conn.cursor()

    # Table 1: Incidents
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS incidents (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_number TEXT UNIQUE NOT NULL,
            title           TEXT NOT NULL,
            description     TEXT,
            priority        TEXT,
            category        TEXT,
            status          TEXT DEFAULT 'new',
            caller          TEXT,
            created_at      TEXT,
            fetched_at      TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Table 2: AI Analysis
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ai_analysis (
            id                   INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_number      TEXT NOT NULL,
            ai_summary           TEXT,
            root_cause           TEXT,
            business_impact      TEXT,
            validated_priority   TEXT,
            team_to_assign       TEXT,
            recommended_action   TEXT,
            escalate             TEXT,
            created_at           TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Table 3: Claims (from schema)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS claim (
            id TEXT PRIMARY KEY,
            batch_id TEXT UNIQUE NOT NULL,
            claim_number TEXT UNIQUE NOT NULL,
            member_id TEXT UNIQUE NOT NULL,
            status TEXT NOT NULL,
            amount REAL NOT NULL,
            description TEXT,
            created_date TEXT,
            last_updated TEXT,
            notes TEXT
        )
    """)
    # Table 4: Audit Logs
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            action         TEXT NOT NULL,
            tool           TEXT,
            status         TEXT,
            details        TEXT,
            incident_number TEXT,
            duration_ms    INTEGER,
            created_at     TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()

def init_db_from_schema(schema_path=SCHEMA_FILE):
    if not os.path.exists(DB_FILE):
        conn = get_connection()
        with open(schema_path, 'r') as f:
            conn.executescript(f.read())
        conn.commit()
        conn.close()
        print(f"Database initialized from {schema_path}.")
    else:
        print("Database already exists.")

if __name__ == '__main__':
    create_tables()
    init_db_from_schema()

